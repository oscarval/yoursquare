<?php 
    include('cabecera.php');
    echo "<link href='css/style-user.css' rel='stylesheet' type='text/css' />";
    echo "<link href='css/style_XBZ.css' rel='stylesheet' type='text/css' />";
    echo "<script src='js/likes.js'></script>";
    include("indexsidebar.php");
    include('square_detail_content.php');
    include('footer.php'); 
?>
