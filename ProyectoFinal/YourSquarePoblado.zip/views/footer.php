<!-- Footer -->
    <footer id='footer'>
      <address>
        Por <a href='mailto:info@yoursquare.com'>YourSquare</a>
      </address>
      <p>Copyright YourSquare 2017</p>
    </footer>
	<!-- Fin Footer -->
  </body>
</html>
