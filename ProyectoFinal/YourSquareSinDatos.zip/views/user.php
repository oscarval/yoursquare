<?php 
    include('cabecera.php');
    include('usersidebar.php');
    include('usercontent.php');
    include('footer.php'); 
?>



