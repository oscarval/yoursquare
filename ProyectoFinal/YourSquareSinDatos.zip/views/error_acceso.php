<main id="main">
  <section class="intro">
		<h1>Acceso restringido</h1>
    <p>Solo usuarios registrados pueden acceder. Por favor inicie sesión.</p>    
  </section>
</main>
<!-- Fin Main Content -->
