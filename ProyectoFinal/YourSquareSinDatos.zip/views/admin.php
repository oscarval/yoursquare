<!DOCTYPE html>
<html lang="es">
  <head>
    <title>
      YourSquare
    </title>
    <meta charset="UTF-8">
  <!-- Link CSS -->
    <link href="https://fonts.googleapis.com/css?family=Monoton|PT+Sans" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <link href="css/style_admin.css" rel="stylesheet" type="text/css" />
  </head>
      <?php include('cabecera.php') ?>
      <?php include('adminsidebar.php') ?>
      <?php include('adminContent.php') ?>
      <?php include('footer.php') ?>
      </body>
      </html>
