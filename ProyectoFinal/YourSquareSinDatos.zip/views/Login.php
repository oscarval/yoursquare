<form action="../controller/Procesar_login.php" method="POST">
  <div class="form_container">
    <h3 class="iniciar-sesion">Iniciar Sesión</h3>
    <div>
      <input type="text" placeholder="Usuario" name="uname" required>
      <input type="password" placeholder="Contraseña" name="psw" required>
    </div>
    <button id="button-submit" type="submit">Login</button>
  </div>

</form>
