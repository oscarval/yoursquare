<aside id="sidebar-left">
		  <form id="searchform">
		  <input type="search" placeholder="Buscar mensaje..."/>
		  <button type="submit">Buscar</button>
		  </form>
		  <h2> Carpetas </h2>
		<ul class="Subcarpetas">
			<li><a href="NuevoMensaje.php"> Nuevo Mensaje </a></li>
			<li><a href="BandejaEntrada.php"> Bandeja de entrada </a></li>
			<li><a href="MensajesEnviados.php"> Mensajes enviados </a></li>
		</ul>
    </aside>