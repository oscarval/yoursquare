<?php
    include("cabecera.php");
?>
 <main id='main-withoutsidebar'>
    <!-- <main id='main'> -->
	  <section class='intro'>
		<h1>¿Que es YourSquare? </h1>
		<p>Es un sitio donde puedes crear tu propio square y personalizarlo a tu gusto para luego tener la oportunidad de compartirlo con los demas usuarios
		para asi recibir likes.</p>
		<h1>¿Que es un 'square'?</h1>
		<p>Un square es un cuadrado que puedes personalizar a tu gusto, poniendole imagenes, fondo, letras, etc, es decir es tu pequeño espacio personal. </p>
		<h1>¿Como puede mi square aparecer en la pagina principal?</h1>
		<p>Solo los mejores squares mejor votados por los usuarios apareceran la pagina principal, asi que no dudes en hacer tu square unico y original!.</p>
		<h1>¿Es gratis?</h1>
		<p>Yoursquare es totalmente gratis asi que no dudes en registrarte y en invitar a tus amigos!.</p>
		<h1>¿Quien desarrolla YourSquare?</h1>
		<p>YourSquare esta desarrollado por los estudiantes de la asignatura de aplicaciones de web de la universidad complutense de madrid </p>
	  </section>
    </main>


<?php include("footer.php"); ?>

</body>
</html>
