<?php
    include("cabecera.php");
    include("indexsidebar.php");
    include("indexcontent.php");
    include("footer.php");
?>
