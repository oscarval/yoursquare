<?php
echo "<main id='main-withoutsidebar-right'>
    <!-- <main id='main'> -->
	  <section class='intro'>
		<div class='container'>
            <a href='square_detail.php'><div class='item'>1</div></a>
            <a href='square_detail.php'><div class='item'>2</div></a>
            <a href='square_detail.php'><div class='item'>3</div></a>
            <a href='square_detail.php'><div class='item'>4</div></a>
            <a href='square_detail.php'><div class='item'>5</div></a>
            <a href='square_detail.php'><div class='item'>6</div></a>
            <a href='square_detail.php'><div class='item'>7</div></a>
            <a href='square_detail.php'><div class='item'>8</div></a>
            <a href='square_detail.php'><div class='item'>9</div></a>
        </div>
	  </section>
    </main>";
?>