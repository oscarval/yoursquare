<!-- sidebar izquierdo -->
    <aside id="sidebar-left">
     <p>Squares recientes</p>
     <ul>
     <li><a href="square_detail.html">Square1</a></li>
     <li><a href="square_detail.html">Square2</a></li>
     <li><a href="square_detail.html">Square3</a></li>
     <li><a href="square_detail.html">+</a></li>
     </ul>
     <p>Squares menos valorados</p>
     <ul>
     <li><a href="square_detail.html">Square1</a></li>
     <li><a href="square_detail.html">Square2</a></li>
     <li><a href="square_detail.html">Square3</a></li>
     <li><a href="square_detail.html">+</a></li>
     </ul>
     <p>Squares más valorados</p>
     <ul>
     <li><a href="square_detail.html">Square1</a></li>
     <li><a href="square_detail.html">Square2</a></li>
     <li><a href="square_detail.html">Square3</a></li>
     <li><a href="square_detail.html">+</a></li>
     </ul>
     </aside>