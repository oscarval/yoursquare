<?php
echo "ide id='sidebar-left'>
        <h3>Dominik F</h3>
        <h4>Miembro desde:</h4>
        <span> 27/03/2017 </span>
        <h4>Suma de like totales</h4>
        <span class='like'>230</span>
        <span class='dislike'></span><!-- Si la puntuación fuese negativa se pondria en rojo -->
        <h4>Intereses</h4>
        <span>Informatica, Artes Marciales, Videojuegos...</span>
        <h4>País</h4>
        <span>España</span>

    </aside>";

#Esto habra que cambiarlo entero, hay que acceder a la base de datos del usuario y
#sacar de ahi toda la información para que se represente en el sidebar.
>